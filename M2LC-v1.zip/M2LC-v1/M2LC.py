import numpy as np
import warnings
import pandas as pd
from  M2LC_discrete import M2LC_discrete
from M2LC_continuous import M2LC_continuous
import matlab.engine
import matlab
import scipy.io as sio
eng = matlab.engine.start_matlab()



def M2LC(data, alpha, L,k1,k2,datatype):
    if datatype == 'discrete':
        selfea = M2LC_discrete(data,alpha,L,k1,k2)
    else:
        selfea = M2LC_continuous(data,alpha,L,k1,k2)

    return selfea
if __name__ == "__main__":
    """An example of M2LC"""

    dataset = sio.loadmat("data\CHD_49_train.mat")
    data = dataset["train"]
    alpha = 0.05 # Significance level
    L = 6 # number of labels
    k1 = 0.3;k2 = 0.5 # parameters
    datatype = "continuous" # discrete or continuous
    selfea = M2LC(data,alpha,L,k1,k2,datatype)