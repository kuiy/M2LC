import numpy as np
import time
from common.knn import *
from common import evaluate as ev

"""ML_KNN"""
class ML_kNN(object):
    s = 1
    k = 10
    label_num = 0
    train_data_num = 0
    train_data = np.array([])
    train_target = np.array([])
    rt1 = np.array([])
    Ph1 = np.array([])
    Ph0 = np.array([])
    Peh1 = np.array([])
    Peh0 = np.array([])
    predict_labels = np.array([])

    def __init__(self, _train_data, _train_target, _k):
        self.train_data = _train_data
        self.train_target = _train_target
        self.k = _k
        self.labels_num = _train_target.shape[1]
        self.train_data_num = self.train_data.shape[0]
        self.Ph1 = np.zeros((self.labels_num,))
        self.Ph0 = np.zeros((self.labels_num,))
        self.Peh1 = np.zeros((self.labels_num, self.k + 1))
        self.Peh0 = np.zeros((self.labels_num, self.k + 1))

    def fit(self):
        for i in range(self.labels_num):
            y = 0
            for j in range(self.train_data_num):
                if self.train_target[j][i] == 1:
                    y = y + 1
            self.Ph1[i] = (self.s + y) / (self.s * 2 + self.train_data_num)
        self.Ph0 = 1 - self.Ph1

        # computing the posterior probabilities
        for i in range(self.labels_num):
            c1 = np.zeros((self.k + 1,))
            c0 = np.zeros((self.k + 1,))
            for j in range(self.train_data_num):
                temp = 0
                KNN = knn(self.train_data, j, self.k)

                for k in range(self.k):
                    if self.train_target[int(KNN[k])][i] == 1:
                        temp = temp + 1
                if self.train_target[j][i] == 1:
                    c1[temp] = c1[temp] + 1
                else:
                    c0[temp] = c0[temp] + 1
            for l in range(self.k + 1):
                self.Peh1[i][l] = (self.s + c1[l]) / (self.s * (self.k + 1) + c1.sum())
                self.Peh0[i][l] = (self.s + c0[l]) / (self.s * (self.k + 1) + c0.sum())
    # computing yt and rt
    def predict(self, _test_data):
        self.rtl = np.zeros((_test_data.shape[0], self.labels_num))
        test_data_num = _test_data.shape[0]
        self.predict_labels = np.zeros((test_data_num, self.labels_num))
        for i in range(test_data_num):
            KNN = knn1(self.train_data, _test_data[i], self.k)
            for j in range(self.labels_num):
                temp = 0
                y1 = 0
                y0 = 0
                for k in range(self.k):
                    if self.train_target[int(KNN[k])][j] == 1:
                        temp = temp + 1
                y1 = self.Ph1[j] * self.Peh1[j][temp]
                y0 = self.Ph0[j] * self.Peh0[j][temp]
                self.rtl[i][j] = self.Ph1[j] * self.Peh1[j][temp] / (
                            self.Ph1[j] * self.Peh1[j][temp] + self.Ph0[j] * self.Peh0[j][temp])
                if y1 > y0:
                    self.predict_labels[i][j] = 1
                else:
                    self.predict_labels[i][j] = 0
        return self.predict_labels

    def evaluate(self, _test_target):  # the function must be invoked after the predict function has been invoked
        HamLos = ev.HammingLoss(self.predict_labels, _test_target)
        avgpre = ev.avgprec(self.rtl, _test_target)
        coverage = ev.Coverage(self.rtl, _test_target)
        rlos = ev.rloss(self.rtl, _test_target)
        subsetaccuracy = ev.SubsetAccuracy(self.predict_labels, _test_target)
        Fmi = ev.Fmicro(self.predict_labels,_test_target)
        Fma = ev.Fmacro(self.predict_labels,_test_target)
        return HamLos,avgpre,coverage,rlos,subsetaccuracy,Fmi,Fma

"""Our method is started here"""
if __name__ == "__main__":

    from scipy import io as sio
    import matlab.engine
    import matlab
    from M2LC import M2LC
    eng = matlab.engine.start_matlab()


    path1 = "data\CHD_49_train.mat"
    path2 = "data\CHD_49_test.mat"

    data1 = sio.loadmat(path1);data2 = sio.loadmat(path2)
    data_train = data1["train"];data_test = data2["test"]

    x,y = np.shape(data_train)
    L = 6;f = y - L # L is number of labels, f is number of features
    k1 = 0.1 # parameter 1
    k2 = 0.1 # parameter 2
    alpha = 0.05 # significance level
    datatype = "continuous" # the data type of data set
    x_train = data_train[:,0:f];y_train = data_train[:,f:y]
    x_test = data_test[:,0:f];y_test=data_test[:,f:y]
    start_time = time.process_time()
    selfea = M2LC(data_train, alpha, L, k1, k2, datatype)
    end_time = time.process_time()
    time = end_time - start_time
    selfea.sort(key=None, reverse=False)
    sel_temp = len(selfea)
    for i in range(len(selfea)):
        selfea[i] = int(selfea[i])
    x_train = x_train[:, selfea]
    x_test = x_test[:, selfea]
    mlKnn = ML_kNN(x_train, y_train, 10)
    mlKnn.fit()
    labels1 = mlKnn.predict(x_test)
    HamLos, avgpre, coverage, rlos, subsetaccuracy, Fmi, Fma = mlKnn.evaluate(y_test)

    print("------------------------------")
    print("Hamming loss(↓): "+str(HamLos))
    print("Average precision(↑): " + str(avgpre))
    print("Coverage(↓): " + str(coverage))
    print("Ranking loss(↓): " + str(rlos))
    print("Subset accury(↑): "+ str(subsetaccuracy))
    print("Fmicro(↑): " + str(Fmi))
    print("Fmacro(↑): " + str(Fma))
    print("time: " + str(time))





